# Reyfield FPS Unlocker

Minimal Android/Kotlin starter project with:
- Shizuku API integration (server status + permission request)
- Launcher-app picker
- Persistent game selection (saved after closing the app)
- Launch selected games from the list
- 60/90/120/144 FPS profile selector UI

## Important limitation

The FPS selector in this starter is a profile/UI choice only. It does not claim to remove a game's internal FPS cap. Shizuku grants shell/ADB-level access, but available operations depend on Android version, OEM firmware, and granted shell permissions. A game may enforce its own frame-rate limit or whitelist supported devices.

## Build

1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on your Android device.

## Shizuku setup

1. Install Shizuku from its official website: https://shizuku.rikka.app/
2. On Android 11+, start Shizuku using Wireless debugging as described in its guide.
3. Open Reyfield FPS Unlocker.
4. Tap **SHIZUKU İZNİ VER** and approve the permission prompt.

Shizuku must be started again after reboot on non-rooted devices.

## Project details

- Application ID: `com.reyfield.fpsunlocker`
- Minimum Android: 6.0 (API 23)
- Compile SDK: 35
- Shizuku API: 13.1.5

The Shizuku API dependency and provider are based on the official RikkaApps Shizuku-API documentation.


## Version 1.1.0
- Added saved game selection using Android SharedPreferences.
- Added an **AÇ** action to launch a selected installed app.
- Kept the package lean rather than padding the APK with meaningless files.
