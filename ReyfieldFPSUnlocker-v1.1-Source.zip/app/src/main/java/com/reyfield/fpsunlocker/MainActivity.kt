package com.reyfield.fpsunlocker

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku

private const val SHIZUKU_PERMISSION_CODE = 7312

data class LaunchableApp(
    val label: String,
    val packageName: String
)

class MainActivity : ComponentActivity() {

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_CODE) {
                shizukuGranted.value = grantResult == PackageManager.PERMISSION_GRANTED
                shizukuRunning.value = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
            }
        }

    private val shizukuRunning = mutableStateOf(false)
    private val shizukuGranted = mutableStateOf(false)

    private val prefs by lazy { getSharedPreferences("reyfield_settings", MODE_PRIVATE) }

    private fun loadSavedPackages(): Set<String> =
        prefs.getStringSet("selected_packages", emptySet())?.toSet() ?: emptySet()

    private fun savePackages(packages: Set<String>) {
        prefs.edit().putStringSet("selected_packages", packages.toSet()).apply()
    }

    private fun launchPackage(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Shizuku.addRequestPermissionResultListener(permissionListener)
        refreshShizukuState()

        setContent {
            ReyfieldApp(
                running = shizukuRunning.value,
                granted = shizukuGranted.value,
                apps = remember { loadLaunchableApps() },
                initialSelection = loadSavedPackages(),
                onSaveSelection = { savePackages(it) },
                onLaunchApp = { launchPackage(it) },
                onConnect = { requestShizukuPermission() }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refreshShizukuState()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun refreshShizukuState() {
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        shizukuRunning.value = running
        shizukuGranted.value = running &&
            runCatching {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }.getOrDefault(false)
    }

    private fun requestShizukuPermission() {
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!running) {
            shizukuRunning.value = false
            return
        }

        if (Shizuku.isPreV11()) return

        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            shizukuGranted.value = true
        } else {
            Shizuku.requestPermission(SHIZUKU_PERMISSION_CODE)
        }
    }

    @Suppress("DEPRECATION")
    private fun loadLaunchableApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { resolveInfo ->
                val activityInfo = resolveInfo.activityInfo ?: return@mapNotNull null
                LaunchableApp(
                    label = resolveInfo.loadLabel(packageManager).toString(),
                    packageName = activityInfo.packageName
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}

@Composable
private fun ReyfieldApp(
    running: Boolean,
    granted: Boolean,
    apps: List<LaunchableApp>,
    initialSelection: Set<String>,
    onSaveSelection: (Set<String>) -> Unit,
    onLaunchApp: (String) -> Unit,
    onConnect: () -> Unit
) {
    val dark = Color(0xFF101114)
    val panel = Color(0xFF1B1D22)
    val red = Color(0xFFFF3D55)
    val muted = Color(0xFF9A9DA7)
    var selectedApps by remember { mutableStateOf(initialSelection) }
    var showPicker by remember { mutableStateOf(false) }
    var selectedFps by remember { mutableIntStateOf(120) }
    var message by remember { mutableStateOf("Bir oyun ekleyerek başlayabilirsin.") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = dark,
            surface = panel,
            primary = red,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = dark
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "REYFIELD",
                            color = Color.White,
                            fontSize = 25.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )
                        Text(
                            "FPS UNLOCKER",
                            color = red,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 3.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(red.copy(alpha = 0.14f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = red)
                    }
                }

                Spacer(Modifier.height(24.dp))

                PanelCard(panel) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = red)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Shizuku bağlantısı", fontWeight = FontWeight.Bold)
                            Text(
                                when {
                                    !running -> "Shizuku çalışmıyor"
                                    !granted -> "İzin bekleniyor"
                                    else -> "Bağlandı ve izin verildi"
                                },
                                color = muted,
                                fontSize = 12.sp
                            )
                        }
                        val statusColor = if (running && granted) Color(0xFF48D597) else red
                        Box(
                            Modifier
                                .size(9.dp)
                                .background(statusColor, RoundedCornerShape(50))
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = onConnect,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = red),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (granted) "BAĞLANTIYI KONTROL ET" else "SHIZUKU İZNİ VER")
                    }
                    if (!running) {
                        Text(
                            "Önce Shizuku uygulamasından servisi başlat.",
                            color = muted,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))

                PanelCard(panel) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = red)
                        Spacer(Modifier.width(10.dp))
                        Text("FPS profili", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(60, 90, 120, 144).forEach { fps ->
                            val active = selectedFps == fps
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedFps = fps },
                                color = if (active) red else Color(0xFF292C33),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    "$fps",
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(
                        "Bu seçim bir profildir; oyunun FPS kilidini tek başına kaldırmaz.",
                        color = muted,
                        fontSize = 11.sp
                    )
                }

                Spacer(Modifier.height(16.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Oyunlarım", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("${selectedApps.size} uygulama eklendi", color = muted, fontSize = 12.sp)
                    }
                    FilledTonalButton(
                        onClick = { showPicker = true },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = red.copy(alpha = 0.18f),
                            contentColor = red
                        )
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("EKLE")
                    }
                }

                Spacer(Modifier.height(10.dp))

                if (selectedApps.isEmpty()) {
                    PanelCard(panel) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Games, contentDescription = null, tint = muted,
                                modifier = Modifier.size(30.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("Henüz oyun eklenmedi", fontWeight = FontWeight.SemiBold)
                            Text("Ekle butonuna basıp oyununı seç.", color = muted, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(selectedApps.toList()) { packageName ->
                            val app = apps.firstOrNull { it.packageName == packageName }
                            PanelCard(panel) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Games, contentDescription = null, tint = red)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(app?.label ?: packageName, fontWeight = FontWeight.SemiBold)
                                        Text(packageName, color = muted, fontSize = 10.sp)
                                    }
                                    TextButton(onClick = { onLaunchApp(packageName) }) {
                                        Text("AÇ", color = Color(0xFF48D597), fontSize = 11.sp)
                                    }
                                    TextButton(onClick = {
                                        selectedApps = selectedApps - packageName
                                        onSaveSelection(selectedApps)
                                    }) {
                                        Text("KALDIR", color = red, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.weight(1f))
                Text(
                    message,
                    color = muted,
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    "REYFIELD FPS • v1.0.0",
                    color = Color(0xFF62656E),
                    fontSize = 10.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            if (showPicker) {
                AlertDialog(
                    onDismissRequest = { showPicker = false },
                    title = { Text("Uygulama ekle") },
                    text = {
                        LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                            items(apps) { app ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedApps = selectedApps + app.packageName
                                            onSaveSelection(selectedApps)
                                            message = "${app.label} listeye eklendi."
                                            showPicker = false
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Games, contentDescription = null, tint = red)
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(app.label, fontWeight = FontWeight.Medium)
                                        Text(app.packageName, color = muted, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showPicker = false }) { Text("KAPAT") }
                    },
                    containerColor = panel,
                    titleContentColor = Color.White,
                    textContentColor = Color.White
                )
            }
        }
    }
}

@Composable
private fun PanelCard(
    color: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        color = color,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}
